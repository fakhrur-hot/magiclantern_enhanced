/* Dual ISO interface */

extern WEAK_FUNC(ret_0) int dual_iso_set_enabled(bool enabled);

extern WEAK_FUNC(ret_0) int dual_iso_is_enabled();

extern WEAK_FUNC(ret_0) int dual_iso_is_active();

extern WEAK_FUNC(ret_0) int dual_iso_get_alternate_iso(); /* raw iso values */

extern WEAK_FUNC(ret_0) int dual_iso_set_alternate_iso(int raw_iso);

extern WEAK_FUNC(ret_0) int dual_iso_calc_dr_improvement(int iso1, int iso2); /* ev x100 */

extern WEAK_FUNC(ret_0) int dual_iso_get_dr_improvement(); /* with current settings */
